import React from 'react';
import ToDo from './ToDo';

export default function RootComponent() {
    return <ToDo />;
}