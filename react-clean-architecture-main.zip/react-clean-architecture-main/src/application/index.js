/* eslint-disable import/no-unresolved */
import store from './store';

export default store;
