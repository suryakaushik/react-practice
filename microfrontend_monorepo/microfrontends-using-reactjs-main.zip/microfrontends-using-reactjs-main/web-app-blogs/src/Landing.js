import React, { useState, useEffect } from "react";

export default function RandomCat() {
  return (
    <div>
     <h3>Footer</h3>
    </div>
  );
}
