const commonFunction = require("@sharecode/common");
commonFunction();
