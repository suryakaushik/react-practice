module.exports = () => {
	console.log("Welcome to KPITENG");
}
